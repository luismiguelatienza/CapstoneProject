<?php


// Start the session
session_start();

// Set session variables
$_SESSION['username'] = 'john_doe';
$_SESSION['user_role'] = 'admin';

// Access session variables
echo 'Username: ' . $_SESSION['username'] . '<br>';
echo 'User Role: ' . $_SESSION['user_role'] . '<br>';

?>