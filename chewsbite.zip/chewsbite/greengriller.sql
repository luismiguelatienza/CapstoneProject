-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2024 at 05:27 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `greengriller`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`u_id` int(11) NOT NULL,
  `u_image` varchar(200) NOT NULL,
  `u_name` varchar(200) NOT NULL,
  `u_pass` varchar(200) NOT NULL,
  `u_uni_no` bigint(20) NOT NULL,
  `u_age` int(11) NOT NULL,
  `u_weight` decimal(5,2) NOT NULL,
  `u_height` decimal(5,2) NOT NULL,
  `u_smoke` enum('yes','no') NOT NULL,
  `u_alcohal` enum('yes','no') NOT NULL,
  `u_excersie` enum('yes','no') NOT NULL,
  `u_plan` enum('dietary','workout','Normal') NOT NULL,
  `bmi` int(11) NOT NULL,
  `cal` int(11) NOT NULL,
  `orders` int(255) NOT NULL,
  `order_date` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `u_image`, `u_name`, `u_pass`, `u_uni_no`, `u_age`, `u_weight`, `u_height`, `u_smoke`, `u_alcohal`, `u_excersie`, `u_plan`, `bmi`, `cal`, `orders`, `order_date`) VALUES
(1, 'admin.png', 'user1', 'admin', 5220924196673207, 30, '79.00', '177.00', '', '', '', '', 0, 0, 0, '0000-00-00');


--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`u_id`), ADD UNIQUE KEY `u_uni_no` (`u_uni_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
