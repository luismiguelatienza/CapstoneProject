<?php

class Functions{
    private $DBHOST = 'localhost';
    private $DBUSER = 'root';
    private $DBPASS = '';
    private $DBNAME = 'greengriller';
    public $conn;

    public function __construct(){
        try{
            $this->conn = mysqli_connect($this->DBHOST, $this->DBUSER, $this->DBPASS, $this->DBNAME);
            if(!$this->conn){  
                throw new Exception('Connection was not established');
            }
        }
        catch(Exception $e) {
            echo 'Message: ' .$e->getMessage();
        }
    }

    public function validate($string){
        $string_vali = mysqli_real_escape_string($this->conn, trim(strip_tags($string)));
        $string_vali = urldecode($string_vali);
        return $string_vali;
    }

    public function insert($tb_name, $tb_field){
        $q_data = "";
        foreach($tb_field as $q_key => $q_value){
            $q_data = $q_data."$q_key='$q_value',";
        }
        $q_data = rtrim($q_data,",");

        $query = "INSERT INTO $tb_name SET $q_data";
        $insert_fire = mysqli_query($this->conn, $query);

        if($insert_fire){
            return $insert_fire;
        } else {
            return false;
        }
    }

    public function user_verify($tb_name, $condition, $op="AND"){
        $field_data = "";
        foreach($condition as $d_key => $d_value){
            $field_data .= "$d_key='$d_value' $op ";
        }
        
        $field_data = rtrim($field_data,"$op ");
        
        $select = "SELECT * FROM $tb_name WHERE $field_data";
        $select_fire = mysqli_query($this->conn, $select);

        if(mysqli_num_rows($select_fire) == 1){
            return true;
        } else {
            return false;
        }
    }

    public function select_assoc($tb_name, $condition) {
        $field_data = "";
        foreach ($condition as $d_key => $d_value) {
            $field_data .= "$d_key='$d_value' AND ";
        }

        $field_data = rtrim($field_data, "AND ");

        $select = "SELECT * FROM $tb_name WHERE $field_data";
        $select_fire = mysqli_query($this->conn, $select);

        if ($select_fire) {
            return mysqli_fetch_assoc($select_fire);
        } else {
            return false;
        }
    }
}

?>
