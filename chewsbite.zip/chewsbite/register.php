<?php



$server = "localhost";
$username = "root";
$password = "";
$dbname = "greengriller";
/* $server = "localhost";
$username = "root";
$password = "";
$dbname = "greengriller"; */

$conn = mysqli_connect($server, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['done'])) {

    $name = mysqli_real_escape_string($conn, $_REQUEST['u_name']);
    $age = mysqli_real_escape_string($conn, $_REQUEST['u_age']);
    $weight = mysqli_real_escape_string($conn, $_REQUEST['u_weight']);
    $height = mysqli_real_escape_string($conn, $_REQUEST['u_height']);
    $u_hidden_bmi = mysqli_real_escape_string($conn, $_REQUEST['u_hidden_bmi']);
    $u_hidden_bmr = mysqli_real_escape_string($conn, $_REQUEST['u_hidden_bmr']);
// Use isset to check if the radio button is checked and assign the corresponding value
$smoke = isset($_POST['u_smoke']) ? mysqli_real_escape_string($conn, $_POST['u_smoke']) : '';
$alcohal = isset($_POST['u_alcohal']) ? mysqli_real_escape_string($conn, $_POST['u_alcohal']) : '';
$excersie = isset($_POST['u_excersie']) ? mysqli_real_escape_string($conn, $_POST['u_excersie']) : '';
$plan = isset($_POST['u_plan']) ? mysqli_real_escape_string($conn, $_POST['u_plan']) : '';

    $pass = mysqli_real_escape_string($conn, $_REQUEST['u_pass']);
    $un = mysqli_real_escape_string($conn, $_REQUEST['u_uni_no']);

    // File upload handling
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $folder = "./images/user/" . $filename;

    if (move_uploaded_file($tempname, $folder)) {
        $sql = "INSERT INTO user (u_name, u_age, u_pass, u_weight, u_height, u_smoke, u_alcohal, u_excersie, u_plan, u_uni_no, u_image, bmi, cal) VALUES ('$name', '$age', '$pass', '$weight', '$height', '$smoke', '$alcohal', '$excersie', '$plan', '$un', '$filename', '$u_hidden_bmi', '$u_hidden_bmr')";

        if (mysqli_query($conn, $sql)) {
            // Record inserted successfully
            header('Location: login.php');
            exit();
        } else {
            // Error in SQL query
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        // Error in file upload
        echo "Error uploading file.";
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Chews Bite - Quality delivery or takeaway food">
    <meta name="author" content="Ansonika">
    <title>Chews Bite - Quality delivery or takeaway food</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/7217/7217494.png" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- SPECIFIC CSS -->
    <link href="css/order-sign_up.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>

<body id="register_bg">

    <div id="register">
        <aside>
            <figure>
                <a href="index.php"><span style="font-weight: 800;font-size: 32px;"><span style="color:#E38C3F">Chews</span> Bite</span></a>
            </figure>





            <form class="form" method="post" enctype="multipart/form-data" action="">
                <div class="form-group">
                    <input type="hidden" value="<?php echo(rand(1000000000000000, 10000000000000000)); ?>"
                        class="form-control item" id="u_uni_no" placeholder="name" name="u_uni_no">
                </div>
                <div class="form-group">
                    <div class="p-4">
                        <div class="picture-container">
                            <div class="picture">
                                <img src="https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-Free-Image.png"
                                    class="picture-src" id="wizardPicturePreview" title="">
                                <input type="file" id="wizard-picture" class="btn_1 gradient full-width" name="uploadfile" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" id="u_name" placeholder="Name" name="u_name" required>
                    <i class="icon_pencil-edit"></i>
                </div>


                <div class="form-group">
    <select class="form-control" id="u_gender" name="u_gender" required>
        <option value="" disabled selected>Select Gender</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
    </select>
    <i class="icon_pencil-edit"></i>
</div>


                
                
                
                <div class="form-group">
                    <input type="number" class="form-control" id="u_age" placeholder="Age" name="u_age" required>
                    <i class="icon_pencil-edit"></i>
                </div>
                <!--  -->                
                <div class="form-group">
                    <input type="number" class="form-control" id="u_weight" placeholder="Weight (in kg)" name="u_weight" required>
                    <i class="icon_pencil-edit"></i>
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" id="u_height" placeholder="Height (in cm)" name="u_height" required>
                    <i class="icon_pencil-edit"></i>
                </div>


                <div class="form-group">
    <select class="form-control" id="u_bmr" name="u_bmr" required>
        <option value="" disabled selected>Lifestyle Workout</option>
        <option value="1.2">Sedentary</option>
        <option value="1.3 ">Lightly</option>
        <option value="1.5">Moderately</option>
        <option value="1.7">Very</option>
        <option value="1.9">Extra</option>
    </select>
    <i class="icon_pencil-edit"></i>
</div>

                

                

                  
                <!--  -->
                <div class="form-group">
                    <input type="password" class="form-control" id="u_pass" placeholder="Password" name="u_pass"
                        required>
                    <i class="icon_lock_alt"></i>
                </div>


                <label id="bmiResult"></label>
                <div id="pass-info" class="clearfix">                    
                </div>
                

                <div class="form-group">
                    <input type="hidden" class="form-control" id="u_hidden_bmi" placeholder="Height" name="u_hidden_bmi">
                    <i class="icon_pencil-edit"></i>
                </div>
                <div class="form-group">
                    <input type="hidden" class="form-control" id="u_hidden_bmr" placeholder="Height" name="u_hidden_bmr">
                    <i class="icon_pencil-edit"></i>
                </div>



                <button type="submit" class="btn_1 gradient full-width" name="done">Register</button>



                
                <div class="text-center mt-2"><small>Already have an acccount? <strong>
                    <a href="login.php">Sign In</a></strong></small>
                </div>
            </form>
            <div class="copy">© 2023 Chews Bite</div>
        </aside>
    </div>
    <!-- /register -->

    <!-- COMMON SCRIPTS -->
    <!-- <script src="js/common_scripts.min.js"></script>
    <script src="js/common_func.js"></script>
    <script src="assets/validate.js"></script> -->

    <!-- SPECIFIC SCRIPTS -->
    <script src="js/pw_strenght.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous">
    </script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js">
    </script>

    <script>
        $(document).ready(function () {
            // Prepare the preview for profile picture
            $("#wizard-picture").change(function () {
                readURL(this);
            });
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
    <script>
        setInterval(checkInputs, 1000);

function checkInputs() {
    var name = document.getElementById("u_name").value.trim();
    var age = document.getElementById("u_age").value.trim();
    var gender = document.getElementById("u_gender").value.trim();
    var weight = document.getElementById("u_weight").value.trim();
    var height = document.getElementById("u_height").value.trim();
    var u_bmr = document.getElementById("u_bmr").value.trim();

    if (name !== "" && age !== "" && gender !== "" && weight !== "" && height !== "") {
        var heightInMeters = parseFloat(height) / 100; // Convert height to meters
        var weightInKg = parseFloat(weight);
        var ageYears = parseFloat(age);
        var u_bmr = parseFloat(u_bmr);

        var bmi = weightInKg / (heightInMeters * heightInMeters);

        // Display BMI result
        var bmiLabel = document.getElementById("bmiResult");
        /* bmiLabel.textContent = "Age: " + age + " years\n" +
                                "Gender: " + gender + "\n" +
                                "Height: " + height + " cm\n" +
                                "Weight: " + weight + " kg\n" +
                                "BMI: " + bmi.toFixed(2); */
                                bmiLabel.textContent = "BMI: " + bmi.toFixed(2);
                                var u_hidden_bmi = document.getElementById("u_hidden_bmi");
                                u_hidden_bmi.value = bmi.toFixed(2);



            if (gender === "male") {
                bmr = (10 * weightInKg) + (6.25 * heightInMeters) - (5 * ageYears) + 5;
            } else if (gender === "female") {
                bmr = (10 * weightInKg) + (6.25 * heightInMeters) - (5 * ageYears) - 161;
            } else {
                // Default value for other genders
                bmr = 0;
            }

            // Display BMR result
            var u_hidden_bmr = document.getElementById("u_hidden_bmr");
            u_hidden_bmr.value = bmr.toFixed(2)*u_bmr;
    } else {
        var bmiLabel = document.getElementById("bmiResult");
        bmiLabel.value = ""; // Clear the label if any input is empty
    }
}
        </script>
</body>

</html>