
<?php

session_start();

require_once 'Config/Functions.php';
$Fun_call = new Functions();

if(!isset($_SESSION['user_name']) && !isset($_SESSION['user_uni_no'])){
    header('Location:login.php');
}


$user_uni_no = $_SESSION['user_uni_no'];


$server = "localhost";
$username = "root";
$password = "";
$dbname = "greengriller";
/* $servername = "localhost";
$username = "root";
$password = "";
$dbname = "greengriller"; */

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if(isset($_SESSION['order'])){

    
    /*$progressbar_load = $_SESSION['cal'];
    $intakecal_load = 2500;
    $calorie_load = $progressbar_load;
    $res_load = ($calorie_load / $intakecal_load) * 100;
    


    
    $progressbar = $_SESSION['order'];
    $intakecal = 2500;
    $calorie = $progressbar;*/
    ///$res = (($calorie / $intakecal) * 100)+$res_load;
    /*$res = (($calorie / $intakecal) * 100);*/


    ///$res_cal = $calorie_load+$calorie;
    /* $res_cal = $calorie_load;


    $order_cal = $_SESSION['order']; */
    
}else{
    /* $progressbar = $_SESSION['cal'];
    $intakecal = 2500;
    $calorie = $progressbar; */
    ///$res = ($calorie / $intakecal) * 100;
    /* $res = 0;


    $res_cal = $calorie;
    $order_cal = 0; */
    /* $sql = "SELECT * FROM user where u_uni_no = '$user_uni_no'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        $progressbar = $row['bmi'];
      }
    } */
}


$today = date('Y-m-d');


if($_SESSION['order_date'] != $today){
    /* echo $today . " " . $_SESSION['order_date']; */
    ///echo 1;
    $progressbar = $_SESSION['cal'];
   
    $calorie = $progressbar;

    $order_cal = 0;
    $res_cal = $calorie;
    $res = 0;
}else{
    /* echo 0; */
    $sql = "SELECT * FROM user where u_uni_no = '$user_uni_no'";
    $result = $conn->query($sql);
    
    
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            $progressbars = $row['orders'];


            $progressbar_load = $progressbars;
            $intakecal_load = 2500;
            $calorie_load = $progressbar_load;
            $res_load = ($calorie_load / $intakecal_load) * 100;
            


            
            $progressbar = $progressbars;
            $intakecal = 2500;
            $calorie = $progressbar;
            ///$res = (($calorie / $intakecal) * 100)+$res_load;
            $res = (($calorie / $intakecal) * 100);


            ///$res_cal = $calorie_load+$calorie;
            $res_cal = $_SESSION['cal'];


            $order_cal = $progressbars;
        }
      }
}
 

$conn->close();


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Chews Bite - Quality delivery or takeaway food">
    <meta name="author" content="Ansonika">
    <title>Chews Bite - Quality delivery or takeaway food</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/7217/7217494.png" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

    <!-- FontAwsome 4 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-mKIavDjClToStY5E8z5+HPFv40LQgnR4Y5PD0L0yvd5X1XanPssA8MCwC23d0C5ZVpU7FjtCXYUnG/SPFYtZLQ==" crossorigin="anonymous" />



    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- SPECIFIC CSS -->
    <link href="css/home.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">
</head>

<body>
                
    <header class="header black_nav clearfix element_to_stick">
        <div class="container">
            <div id="logo">
                <a href="index.php">
                    <span style="font-weight: 800;font-size: 32px;"><span style="color:#E38C3F">Chews</span> Bite</span>
                </a>
            </div>
            <div class="layer"></div>
            <!-- /top_menu -->
            <a href="#0" class="open_close">
                <i class="icon_menu"></i><span>Menu</span>
            </a>
           <nav class="main-menu">
                <div id="header_menu">
                    <a href="#0" class="open_close">
                        <i class="icon_close"></i><span>Menu</span>
                    </a>
                    <a href="index.php"><span style="font-weight: 800;font-size: 32px;"><span style="color:#E38C3F">Chews</span> Bite</span></a>
                </div>
                <ul>
                    <li class="submenu">
                        <a href="index.php" class="show-submenu">Home</a>
                    </li>
                    <li class="submenu">
                        <a href="grid-listing-filterscol.html" class="show-submenu">Restaurants</a>
                    </li>
                    <li><a href="logout.php">Sign Out</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <!-- /header -->

    <main>
        <div class="hero_single version_1">
            <div class="opacity-mask">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-7 col-lg-8">
                            <h1>Delivery or Takeaway Food</h1>
                            <p>The best restaurants at the best price</p>
                        </div>
                    </div>
                    <!-- /row -->
                </div>
            </div>
            <div class="wave hero"></div>
        </div>
        <!-- /hero_single -->
        <!-- /container -->

        <div class="bg_gray">
        <style>
.progress-container {
  width: 300px; /* Width of the progress container */
  height: 20px; /* Height of the progress container */
  border: 3px solid #212529; /* Border for the progress container */
  border-radius: 10px; /* Rounded corners for the progress container */
   /* Hide overflowing progress bar */
}

.progress-bar {
  height: 90%; /* Height of the progress bar */
  
  background-color: #E38C3F; /* Default color of the progress bar */
  width: 0; /* Initial width of the progress bar */
  transition: width 0.3s ease-in-out; /* Smooth transition for width change */
}

</style>
        <center>Cal: <?php echo $order_cal; ?>/<?php echo $res_cal; ?></center>
        <div class="progress-container" style="display: block;
  margin: 0 auto;">
  <div class="progress-bar" id="myProgressBar"></div>
</div>
<script>
// Example usage to update the progress bar width
var progressBar = document.getElementById("myProgressBar");
var progressValue = <?php echo $res; ?>; // Change this value to update progress
progressBar.style.width = progressValue + "%";

</script>
            <!-- <div class="container margin_60_40">
            <progress id="file" class="container" value="32" max="100" style="height: 70px;
    width: 30%;
    display: block;
    margin: 0 auto;"> 32% </progress> -->
                <div class="main_title">
                    <span><em></em></span>
                    <h2>Top Rated Restaurants</h2>
                    <p>Recommended For You</p>
                    <a href="#0">View All &rarr;</a>
                </div>
                <div class="row add_bottom_25">
                    <div class="col-lg-6">
                        <div class="list_home">
                            <ul>
                                <li>
                                    <a href="macdonalds.php">
                                        <figure>
                                            <img src="https://www.tendergreens.com/wp-content/uploads/2023/09/slide-2r.jpg" data-src="https://www.tendergreens.com/wp-content/uploads/2023/09/slide-2r.jpg" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>4.4</strong></div>
                                        <em>Grilled</em>
                                        <h3>Tender Greens</h3>
                                        <small>Quiapo, Metro Manila</small>
                                        <ul>
                                            <li><span class="ribbon off">-10% off</span></li>
                                            <li>Average price PHP 250</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="starbucks.php">
                                        <figure>
                                            <img src="https://freshii.com/wp-content/uploads/2024/03/freshii-logo-with-food-and-leaves.jpg" data-src="https://freshii.com/wp-content/uploads/2024/03/freshii-logo-with-food-and-leaves.jpg" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>4.7</strong></div>
                                        <em>Salads</em>
                                        <h3>Freshii</h3>
                                        <small>Sta. Mesa, Metro Manila</small>
                                        <ul>
                                            <li><span class="ribbon off">-15% 399 min.</span></li>
                                            <li>Average price PHP 200</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="panda-express.php">
                                        <figure>
                                            <img src="https://play-lh.googleusercontent.com/Yhi1IesQYRVLm2C9tq5FIL2cYXxmcUinS0SjhhHDB94-ACQ6t8Zjs3X6Bha89PoqWaFi=w3840-h2160-rw" data-src="https://play-lh.googleusercontent.com/Yhi1IesQYRVLm2C9tq5FIL2cYXxmcUinS0SjhhHDB94-ACQ6t8Zjs3X6Bha89PoqWaFi=w3840-h2160-rw" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>4.5</strong></div>
                                        <em>Balanced</em>
                                        <h3>Dig Inn</h3>
                                        <small>Mandaluyong, Metro Manila</small>
                                        <ul>
                                            <li><span class="ribbon off">-25% GCash</span></li>
                                            <li>Average price PHP 200</li>
                                        </ul>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="list_home">
                            <ul>
                                <li>
                                    <a href="subway.php">
                                        <figure>
                                            <img src="https://vegnews.com/media/W1siZiIsIjM0NDg5L1ZlZ05ld3MuVmVnZ2llR3JpbGxOWUMuanBnIl0sWyJwIiwiY3JvcF9yZXNpemVkIiwiMTU5OHg5NDQrMCswIiwiMTYwMHg5NDZeIix7ImZvcm1hdCI6ImpwZyJ9XSxbInAiLCJvcHRpbWl6ZSJdXQ/VegNews.VeggieGrillNYC.jpg?sha=00dfde2960f31868" data-src="https://vegnews.com/media/W1siZiIsIjM0NDg5L1ZlZ05ld3MuVmVnZ2llR3JpbGxOWUMuanBnIl0sWyJwIiwiY3JvcF9yZXNpemVkIiwiMTU5OHg5NDQrMCswIiwiMTYwMHg5NDZeIix7ImZvcm1hdCI6ImpwZyJ9XSxbInAiLCJvcHRpbWl6ZSJdXQ/VegNews.VeggieGrillNYC.jpg?sha=00dfde2960f31868" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>4.3</strong></div>
                                        <em>Grilled</em>
                                        <h3>Veggie Grill</h3>
                                        <small>Recto Ave, Metro Manila</small>
                                        <ul>
                                            <li><span class="ribbon off">-30% 499 min.</span></li>
                                            <li>Average price PHP 150</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="kfc.php">
                                        <figure>
                                            <img src="https://www.restaurantnews.com/wp-content/uploads/2019/05/Nekter-Juice-Bar-Accelerates-Nationwide-Expansion-Brings-Home-Three-Major-Awards.jpg" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>4.4</strong></div>
                                        <em>Fruits</em>
                                        <h3>Nekter Juice Bar</h3>
                                        <small>Taft Ave, Metro Manila</small>
                                        <ul>
                                            
                                            <li>Average price PHP 150</li>
                                        </ul>
                                    </a>
                                </li>
                                <li>
                                    <a href="tokyo-tokyo.php">
                                        <figure>
                                            <img src="https://www.mycentraljersey.com/gcdn/presto/2022/10/12/PCNJ/9cdc83ef-5500-4cbe-9af3-8e294268162b-TFK_Fall_22_41_2.jpg?crop=4965,2793,x0,y506&width=3200&height=1801&format=pjpg&auto=webp" data-src="https://www.mycentraljersey.com/gcdn/presto/2022/10/12/PCNJ/9cdc83ef-5500-4cbe-9af3-8e294268162b-TFK_Fall_22_41_2.jpg?crop=4965,2793,x0,y506&width=3200&height=1801&format=pjpg&auto=webp" alt="" class="lazy" width="350" height="233">
                                        </figure>
                                        <div class="score"><strong>4.8</strong></div>
                                        <em>Balanced</em>
                                        <h3>True Food Kitchen</h3>
                                        <small>España, Metro Manila</small>
                                        <ul>
                                            
                                            <li>Average price PHP 200</li>
                                        </ul>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /row -->
                <div class="banner lazy" data-bg="url(https://img.freepik.com/premium-photo/banner-free-fast-delivery-service-by-scooter-yellow-background-courier-delivers-food-order-copy-space-ai-generation_235573-2628.jpg?w=1380)">
                    <div class="wrapper d-flex align-items-center opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.3)">
                        <div>
                            <small>Chews Bite</small>
                            <h3>We Deliver to your Office</h3>
                            <p>Enjoy a tasty food in minutes!</p>
                            
                        </div>
                    </div>
                    <!-- /wrapper -->
                </div>
                <!-- /banner -->
            </div>
        </div>
        
        <!-- /bg_gray -->

        <div class="shape_element_2">
            <div class="container margin_60_0">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="box_how">
                                    <figure><img src="img/lazy-placeholder-100-100-white.png" data-src="img/how_1.svg" alt="" width="150" height="167" class="lazy"></figure>
                                    <h3>Easily Order Food from your doorstep</h3>
                                </div>
                                <div class="box_how">
                                    <figure><img src="img/lazy-placeholder-100-100-white.png" data-src="img/how_2.svg" alt="" width="130" height="145" class="lazy"></figure>
                                    <h3>Efficient Delivery</h3>
                                </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                                <div class="box_how">
                                    <figure><img src="img/lazy-placeholder-100-100-white.png" data-src="img/how_3.svg" alt="" width="150" height="132" class="lazy"></figure>
                                    <h3>Enjoy Food with Caution</h3>   
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-lg-5 offset-lg-1 align-self-center">
                        <div class="intro_txt">
                            <div class="main_title">
                                <span><em></em></span>
                                <h2>Start Ordering Now</h2>
                            </div>
                            <p class="lead">Nourishing Choices, Calorie-Wise Delights!</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /shape_element_2 -->

    </main>
    <!-- /main -->

    <footer>
        <div class="wave footer"></div>
        <div class="container margin_60_40 fix_mobile">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <h3 data-bs-target="#collapse_1">Quick Links</h3>
                    <div class="collapse dont-collapse-sm links" id="collapse_1">
                        <ul>
                            <li><a href="about.html">About us</a></li>
                            <li><a href="submit-restaurant.html">Add your restaurant</a></li>
                            <li><a href="help.html">Help</a></li>
                            <li><a href="register.html">My account</a></li>
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="contacts.html">Contacts</a></li>
                        </ul>
                    </div>
                </div>

                        <div class="follow_us">
                            <h5>Follow Us</h5>
                            <ul>
                                <li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/twitter_icon.svg" alt="" class="lazy"></a></li>
                                <li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/facebook_icon.svg" alt="" class="lazy"></a></li>
                                <li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/instagram_icon.svg" alt="" class="lazy"></a></li>
                                <li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/youtube_icon.svg" alt="" class="lazy"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /row-->
                <div class="col-lg-6">
                    <ul class="additional_links">
                        <li><a href="#0">Terms and conditions</a></li>
                        <li><a href="#0">Privacy</a></li>
                        <li><span>© Chews Bite</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!--/footer-->

    <div id="toTop"></div><!-- Back to top button -->
    
<!-- Sign In Modal -->
<div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
    <div class="modal_header">
        <h3>Sign In</h3>
    </div>
    <form>
        <div class="sign-in-wrapper">
            <a href="#0" class="social_bt facebook">Login with Facebook</a>
            <a href="#0" class="social_bt google">Login with Google</a>
            <div class="divider"><span>Or</span></div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" id="email">
                <i class="icon_mail_alt"></i>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="password" id="password" value="">
                <i class="icon_lock_alt"></i>
            </div>
            <div class="clearfix add_bottom_15">
                <div class="checkboxes float-start">
                    <label class="container_check">Remember me
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="float-end"><a id="forgot" href="javascript:void(0);">Forgot Password?</a></div>
            </div>
            <div class="text-center">
                <input type="submit" value="Log In" class="btn_1 full-width mb_5">
                Don’t have an account? <a href="register.html">Sign up</a>
            </div>
            <div id="forgot_pw">
                <div class="form-group">
                    <label>Please confirm login email below</label>
                    <input type="email" class="form-control" name="email_forgot" id="email_forgot">
                    <i class="icon_mail_alt"></i>
                </div>
                <p>You will receive an email containing a link allowing you to reset your password to a new preferred one.</p>
                <div class="text-center"><input type="submit" value="Reset Password" class="btn_1"></div>
            </div>
        </div>
    </form>
    <!--form -->
</div>
<!-- /Sign In Modal -->

<!-- COMMON SCRIPTS -->
<script src="js/common_scripts.min.js"></script>
<script src="js/common_func.js"></script>
<script src="assets/validate.js"></script>

<!-- Autocomplete -->
<script>
function initMap() {
    var input = document.getElementById('autocomplete');
    var autocomplete = new google.maps.places.Autocomplete(input);

    autocomplete.addListener('place_changed', function() {
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }

        var address = '';
        if (place.address_components) {
            address = [
                (place.address_components[0] && place.address_components[0].short_name || ''),
                (place.address_components[1] && place.address_components[1].short_name || ''),
                (place.address_components[2] && place.address_components[2].short_name || '')
            ].join(' ');
        }
    });
}
</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places&callback=initMap"></script>

</body>
</html>