<?php


session_start();


$server = "localhost";
$username = "root";
$password = "";
$dbname = "greengriller";

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);


$user_uni_no = $_SESSION['user_uni_no'];
$order_date = $_SESSION['order_date'];

// Check if it's an AJAX request
if($_SERVER["REQUEST_METHOD"] == "POST") {


	$jsonData = file_get_contents('php://input');
    $data = json_decode($jsonData, true);
    
    // Assume we're expecting some data from the frontend
	$data_from_frontend = $data['key1'];
	

    // You can perform any processing with the data here
    // For example, let's just convert the received data to uppercase

	
	

	$today = date('Y-m-d');
	
	
	if($order_date == $today){
		
		$sql = "SELECT * FROM user where u_uni_no = '$user_uni_no'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$ordercal = $row["orders"];
				$add = $data_from_frontend;


				$sql = "UPDATE user SET orders=$add, order_date = '$today' WHERE u_uni_no=$user_uni_no";
				$conn->query($sql);
				break;
			}
		} else {
			///echo "0 results";
		}


		
	}else{
		
		$sql = "SELECT * FROM user where u_uni_no = '$user_uni_no'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			$add = $data_from_frontend;

			$today = date('Y-m-d');
			$sql = "UPDATE user SET orders=$add, order_date = '$today' WHERE u_uni_no=$user_uni_no";

			$conn->query($sql);
			echo $user_uni_no . " 2";exit;
		} else {
			///echo "0 results";
		}


		
	}


	$conn->close();

	



    /* $processed_data = strtoupper($data_from_frontend);

    // Send the processed data back to the frontend
    echo $processed_data; */
} else {
    // Handle non-AJAX request here if needed
    echo "This is not an AJAX request.";
}
?>
