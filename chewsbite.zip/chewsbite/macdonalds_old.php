<?php


session_start();


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Chews Bite - Quality delivery or takeaway food">
    <meta name="author" content="Ansonika">
    <title>Chews Bite - Quality delivery or takeaway food</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/7217/7217494.png" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-wfiz+C5X46MqOXjz92OSJgtLhM/XFMkHQ3qD2bB5q3bPbs1qz6qSU3A8hITuS2yx0A+ahWvww+0hdmF/e2yt3A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- SPECIFIC CSS -->
    <link href="css/detail-page.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">
<style>

     /* Add this CSS to style the switch toggle button */
     .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #0B643E;
        }

        input:focus + .slider {
            box-shadow: 0 0 1px #2196F3;
        }

        input:checked + .slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }
</style>
</head>

<body data-spy="scroll" data-bs-target="#secondary_nav" data-offset="75">
				
	<header class="header_in clearfix">
        <div class="container">
            <div id="logo">
                <a href="index.php">
                    <span style="font-weight: 800;font-size: 32px;"><span style="color:#E38C3F">Chews</span> Bite</span>
                </a>
            </div>
            <div class="layer"></div>
            <!-- /top_menu -->
            <a href="#0" class="open_close">
                <i class="icon_menu"></i><span>Menu</span>
            </a>
           <nav class="main-menu">
                <div id="header_menu">
                    <a href="#0" class="open_close">
                        <i class="icon_close"></i><span>Menu</span>
                    </a>
                    <a href="index.php"><span style="font-weight: 800;font-size: 32px;"><span style="color:#E38C3F">Chews</span> Bite</span></a>
                </div>
                <ul>
                    <li class="submenu">

                    </li>
                    <li class="submenu">
                        <a href="index.php" class="show-submenu">Home</a>
                    </li>
                    <li class="submenu">
                        <a href="grid-listing-filterscol.html" class="show-submenu">Restaurants</a>
                    </li>
                    <li class="submenu">
                        <a href="grid-listing-filterscol.html" class="show-submenu">Contacts</a>
                    </li>
                    <li id="logout-btn"><a href="logout.php" id="logout-btn">Sign Out</a></li>
                </ul>
            </nav>
        </div>
	</header>
	<!-- /header -->
	
	<main>

		<div class="hero_in detail_page background-image" data-background="url('https://www.tendergreens.com/wp-content/uploads/2023/09/slide-2r.jpg')">
			<div class="wrapper opacity-mask" data-opacity-mask="rgba(0, 0, 0, 0.5)">
				
				<div class="container">
					<div class="main_info">
						<div class="row">
							<div class="col-xl-4 col-lg-5 col-md-6">
								<div class="head"><div class="score"><span>Great<em>650 Reviews</em></span><strong>4.4</strong></div></div>
								<h1>Tender Greens</h1>
								Quiapo, Metro Manila
							</div>
							<div class="col-xl-8 col-lg-7 col-md-6 position-relative">
								<div class="buttons clearfix">
									<span class="magnific-gallery">
										 										<a href="https://www.tendergreens.com/wp-content/uploads/2023/09/slide-2r.jpg" class="btn_hero" title="Macdonalds" data-effect="mfp-zoom-in"><i class="icon_image"></i>View photos</a>
											<a href="img/detail_2.jpg" title="Photo title" data-effect="mfp-zoom-in"></a>
										<a href="img/detail_3.jpg" title="Photo title" data-effect="mfp-zoom-in"></a>
									</span>
									<a href="#0" class="btn_hero wishlist"><i class="icon_heart"></i>Wishlist</a>
								</div>
							</div>
						</div>
						<!-- /row -->
					</div>
					<!-- /main_info -->
				</div>
			</div>
		</div>
		<!--/hero_in-->

		<nav class="secondary_nav sticky_horizontal">
		    <div class="container">
		        <ul id="secondary_nav">
		            <li><a href="#section-1">Starters</a></li>
		            <li><a href="#section-2">Main Courses</a></li>
		            <li><a href="#section-3">Desserts</a></li>
		            <li><a href="#section-4">Drinks</a></li>
		            <li><a href="#section-5"><i class="icon_chat_alt"></i>Reviews</a></li>
		        </ul>
		    </div>
		    <span></span>
		</nav>
		<!-- /secondary_nav -->

		<div class="bg_gray">
		    <div class="container margin_detail">
		        <div class="row">
		            <div class="col-lg-8 list_menu">
		                <section id="section-1">
		                    <h4>Starters</h4>
		                    <div class="row">
                            <div class="col-md-6">
    <a class="menu_item modal_dialog" href="" data-name="Salt and Pepper Chicken" data-price="100" data-calories="186">
        <figure><img src="https://www.kitchensanctuary.com/wp-content/uploads/2021/01/Salt-and-Pepper-Chicken-square-FS.jpg" alt="thumb" class="lazy"></figure>
        <h3  class="add-to-cart-btn">Salt and Pepper Chicken</h3>
        <p>Garlic & Herb marinade</p>
        
        
            <strong>PHP 100</strong>
            <strong >Calories: 186-cal</strong>
        
        
    </a>
</div>
		                        <div class="col-md-6">
		                            <a class="menu_item modal_dialog" href="" data-name="Chipotle BBQ Chicken" data-price="120" data-calories="183">
		                                <figure><img src="https://d3bjzufjcawald.cloudfront.net/public/web/2019-03-06/bb6b6849bd80a9e8629b9a95cd5af8f6/BurgerMcDo-500.jpeg" data-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ15Ro7fbTV16iUi1koNVHxL8GgTD0FysfnHW027uhg7Q&s" alt="thumb" class="lazy"></figure>
		                                <h3  class="add-to-cart-btn">Chipotle BBQ Chicken</h3>
		                                <p>Grilled with Chipotle BBQ</p>
										
		                                <strong>PHP 120</strong>
           								<strong >Calories: 183-cal</strong>
       								 
		                            </a>
		                        </div>
		                    </div>
		                    <!-- /row -->
		                </section>
		                <!-- /section -->
		                <section id="section-2">
		                    <h4>Main Courses</h4>
		                    <div class="row">
		                        <div class="col-md-6">
		                            <a class="menu_item modal_dialog" href="" data-name="Buttermilk Fried Chicken" data-price="140" data-calories="297">
		                                <figure><img src="https://www.browneyedbaker.com/wp-content/uploads/2020/12/buttermilk-fried-chicken-12-square.jpg" data-src="https://www.browneyedbaker.com/wp-content/uploads/2020/12/buttermilk-fried-chicken-12-square.jpg" alt="thumb" class="lazy"></figure>
		                                <h3  class="add-to-cart-btn">Buttermilk Fried Chicken</h3>
		                                <p>Deep Fried Chicken dredged in Buttermilk</p>
									
		                                <strong>PHP 140</strong>
										<strong >Calories: 297-cal</strong>
		                            </a>
		                        </div>
		                        <div class="col-md-6">
		                            <a class="menu_item modal_dialog"  href="" data-name="Baked Falafel" data-price="130" data-calories="82">
		                                <figure><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQmP6IlwcV8-t6z92yG0EGpatxPN-I6u-axBG9JlKNYEA&s" alt="thumb" class="lazy"></figure>
		                                <h3  class="add-to-cart-btn">Baked Falafel</h3>
		                                <p>Baked enriched goodness</p>
		                                <strong>PHP 130</strong>
										<strong >Calories: 82-cal</strong>
										
		                            </a>
		                        </div>
		                    </div>
		                    <!-- /row -->
		                </section>
		                <!-- /section -->
		                <section id="section-3">
		                    <h4>Desserts</h4>
		                    <div class="row">
		                        <div class="col-md-6">
		                            <a class="menu_item modal_dialog"  href="" data-name="Apple Cobbler" data-price="150" data-calories="447">
		                                <figure><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpwgLD4mNc1D6BVCMDpFuT5rKxpz-RIqt3B2mbdizfUg&s" data-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpwgLD4mNc1D6BVCMDpFuT5rKxpz-RIqt3B2mbdizfUg&s" alt="thumb" class="lazy"></figure>
		                                <h3  class="add-to-cart-btn">Apple Cobbler</h3>
		                                <p>Apple infused Cobbler, baked to perfection</p>
		                                <strong>PHP 150</strong>
										<strong >Calories: 447-cal</strong>
		                            </a>
		                        </div>
		                    </div>
		                    <!-- /row -->
		                </section>
		                <!-- /section -->
		                <section id="section-4">
		                    <h4>Drinks</h4>
		                    <div class="row">
		                        <div class="col-md-6">
		                            <a class="menu_item modal_dialog"  href="" data-name="Mint Lemonade" data-price="45" data-calories="109">
		                                <figure><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfwEF9jtfodXUrYv13SJfOBRbRRjnlNlIS70H9iusXjg&s" data-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfwEF9jtfodXUrYv13SJfOBRbRRjnlNlIS70H9iusXjg&s" alt="thumb" class="lazy"></figure>
		                                <h3  class="add-to-cart-btn">Mint Lemonade</h3>
		                                <p>Refreshing and Healthy</p>
		                                <strong>PHP 45</strong>
										<strong >Calories: 109-cal</strong>
		                            </a>
		                        </div>
		                        <div class="col-md-6">
		                            <a class="menu_item modal_dialog"  href="" data-name="Hibiscus Tea" data-price="80" data-calories="82">
		                                <figure><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6mdsj0afyMrNLmEYv-5hF5HybrQ3hTzeh2DJc9zkkSg&s" data-src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6mdsj0afyMrNLmEYv-5hF5HybrQ3hTzeh2DJc9zkkSg&s" alt="thumb" class="lazy"></figure>
		                                <h3  class="add-to-cart-btn">Hibiscus Tea</h3>
		                                <p>Herbal Tea</p>
		                                <strong>PHP 80</strong>
										<strong >Calories: 82-cal</strong>
		                            </a>
		                        </div>
		                    </div>
		                    <!-- /row -->
		                </section>
		                <!-- /section -->
		            </div>
		            <!-- /col -->
		            <div class="col-lg-4" id="sidebar_fixed">
		                <div class="box_order mobile_fixed">
		                    <div class="head">
                         
                            <p>Show Calories Counter</p>
                    <div class="switch">                        
                            <input type="checkbox" id="toggleSwitch" checked>
                            <label class="slider" for="toggleSwitch"></label>
                        </div>

		                        <h3>Order Summary</h3>
		                        <a href="#0" class="close_panel_mobile"><i class="icon_close"></i></a>
		                    </div>
		                    <!-- /head -->
		                    <div class="main">
		                        <ul class="clearfix">
                                        <div id="cart-section">
                                            <h2>Shopping Cart</h2>
                                            <ul id="cart-items" class="py-3"></ul>
                                        </div>
		                        </ul>
		                        <ul class="clearfix">
		                            <li>Delivery fee<span>xx</span></li>
                                    <p><b>Total Calories</b>: <span style="float: inline-end;" id="cart-total-calories">0</span></p>
		                            <li class="total">Total<span id="cart-total">0.00</span></li>
		                        </ul>
		                        <div class="row opt_order">
		                            <div class="col-6">
		                                <label class="container_radio">Delivery
		                                    <input type="radio" value="option1" name="opt_order" checked>
		                                    <span class="checkmark"></span>
		                                </label>
		                            </div>
		                            <div class="col-6">
		                                <!-- <label class="container_radio">Take away
		                                    <input type="radio" value="option1" name="opt_order">
		                                    <span class="checkmark"></span>
		                                </label> -->
		                            </div>
		                        </div>
		                        <div class="dropdown day">
		                            <a href="#" data-bs-toggle="dropdown">Day <span id="selected_day"></span></a>
		                            <div class="dropdown-menu">
		                                <div class="dropdown-menu-content">
		                                    <h4>Which day delivered?</h4>
		                                    <div class="radio_select chose_day">
		                                        <ul>
		                                            <li>
		                                                <input type="radio" id="day_1" name="day" value="Today">
		                                                <label for="day_1">Today<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="day_2" name="day" value="Tomorrow">
		                                                <label for="day_2" style="opacity:.5;">Tomorrow<em>-40%</em></label>
		                                            </li>
		                                        </ul>
		                                    </div>
		                                    <!-- /people_select -->
		                                </div>
		                            </div>
		                        </div>
		                        <!-- /dropdown -->
		                        <div class="dropdown time">
		                            <a href="#" data-bs-toggle="dropdown">Time <span id="selected_time"></span></a>
		                            <div class="dropdown-menu">
		                                <div class="dropdown-menu-content">
		                                    <h4>Lunch</h4>
		                                    <div class="radio_select add_bottom_15">
		                                        <ul>
		                                            <li>
		                                                <input type="radio" id="time_1" name="time" value="12.00am">
		                                                <label for="time_1">12.00<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="time_2" name="time" value="08.30pm">
		                                                <label for="time_2">12.30<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="time_3" name="time" value="09.00pm">
		                                                <label for="time_3">1.00<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="time_4" name="time" value="09.30pm">
		                                                <label for="time_4">1.30<em>-40%</em></label>
		                                            </li>
		                                        </ul>
		                                    </div>
		                                    <!-- /time_select -->
		                                    <h4>Dinner</h4>
		                                    <div class="radio_select">
		                                        <ul>
		                                            <li>
		                                                <input type="radio" id="time_5" name="time" value="08.00pm">
		                                                <label for="time_1">20.00<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="time_6" name="time" value="08.30pm">
		                                                <label for="time_2">20.30<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="time_7" name="time" value="09.00pm">
		                                                <label for="time_3">21.00<em>-40%</em></label>
		                                            </li>
		                                            <li>
		                                                <input type="radio" id="time_8" name="time" value="09.30pm">
		                                                <label for="time_4">21.30<em>-40%</em></label>
		                                            </li>
		                                        </ul>
		                                    </div>
		                                    <!-- /time_select -->
		                                </div>
		                            </div>
		                        </div>
		                        <!-- /dropdown -->
		                        <div class="btn_1_mobile">
		                            <button class="btn_1 gradient full-width mb_5" id="order_now">Order Now</button>
		                        </div>
								<input type="hidden" id="calhidden">
		                            <div class="text-center"><small>No money charged on this steps</small></div>
		                    </div>
		                </div>
		                <!-- /box_order -->
		                <div class="btn_reserve_fixed"><a href="#0" class="btn_1 gradient full-width">View Basket</a></div>
		            </div>
		        </div>
		        <!-- /row -->
		    </div>
		    <!-- /container -->
		</div>
		<!-- /bg_gray -->

		<div class="container margin_30_20">
			<div class="row">
				<div class="col-lg-8 list_menu">
					<section id="section-5">
						<h4>Reviews</h4>
					    <div class="row add_bottom_30 d-flex align-items-center reviews">
					        <div class="col-md-3">
					            <div id="review_summary">
					                <strong>4.4</strong>
					                <em>Great</em>
					                <small>Based on 650 reviews</small>
					            </div>
					        </div>
					        <div class="col-md-9 reviews_sum_details">
					            <div class="row">
					                <div class="col-md-6">
					                    <h6>Food Quality</h6>
					                    <div class="row">
					                        <div class="col-xl-10 col-lg-9 col-9">
					                            <div class="progress">
					                                <div class="progress-bar" role="progressbar" style="width: 90%" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
					                            </div>
					                        </div>
					                        <div class="col-xl-2 col-lg-3 col-3"><strong>9.0</strong></div>
					                    </div>
					                    <!-- /row -->
					                    <h6>Service</h6>
					                    <div class="row">
					                        <div class="col-xl-10 col-lg-9 col-9">
					                            <div class="progress">
					                                <div class="progress-bar" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
					                            </div>
					                        </div>
					                        <div class="col-xl-2 col-lg-3 col-3"><strong>9.5</strong></div>
					                    </div>
					                    <!-- /row -->
					                </div>
					                <div class="col-md-6">
					                    <h6>Punctuality</h6>
					                    <div class="row">
					                        <div class="col-xl-10 col-lg-9 col-9">
					                            <div class="progress">
					                                <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
					                            </div>
					                        </div>
					                        <div class="col-xl-2 col-lg-3 col-3"><strong>6.0</strong></div>
					                    </div>
					                    <!-- /row -->
					                    <h6>Price</h6>
					                    <div class="row">
					                        <div class="col-xl-10 col-lg-9 col-9">
					                            <div class="progress">
					                                <div class="progress-bar" role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
					                            </div>
					                        </div>
					                        <div class="col-xl-2 col-lg-3 col-3"><strong>6.0</strong></div>
					                    </div>
					                    <!-- /row -->
					                </div>
					            </div>
					            <!-- /row -->
					        </div>
					    </div>
					    <!-- /row -->
					     <div id="reviews">
					        <div class="review_card">
					            <div class="row">
					                <div class="col-md-2 user_info">
					                    <figure><img src="img/avatar4.jpg" alt=""></figure>
					                    <h5>Lukas</h5>
					                </div>
					                <div class="col-md-10 review_content">
					                    <div class="clearfix add_bottom_15">
					                        <span class="rating">4.5<small>/5</small> <strong>Rating average</strong></span>
					                        <em>Published 54 minutes ago</em>
					                    </div>
					                    <h4>"Great Location!!"</h4>
					                    <p>The place is the best, would love to go again and eat with my family</p>
					                    <ul>
					                        <li><a href="#0"><i class="icon_like"></i><span>Useful</span></a></li>
					                        <li><a href="#0"><i class="icon_dislike"></i><span>Not useful</span></a></li>
					                        <li><a href="#0"><i class="arrow_back"></i> <span>Reply</span></a></li>
					                    </ul>
					                </div>
					            </div>
					            <!-- /row -->
					        </div>
					        <!-- /review_card -->
					        <div class="review_card">
					            <div class="row">
					                <div class="col-md-2 user_info">
					                    <figure><img src="img/avatar1.jpg" alt=""></figure>
					                    <h5>Marika</h5>
					                </div>
					                <div class="col-md-10 review_content">
					                    <div class="clearfix add_bottom_15">
					                        <span class="rating">4.0<small>/5</small> <strong>Rating average</strong></span>
					                        <em>Published 11 Oct. 2019</em>
					                    </div>
					                    <h4>"Really great dinner!!"</h4>
					                    <p>Ordered, 3 Big Macs, and they were all superb delicious</p>
					                    <ul>
					                        <li><a href="#0"><i class="icon_like"></i><span>Useful</span></a></li>
					                        <li><a href="#0"><i class="icon_dislike"></i><span>Not useful</span></a></li>
					                        <li><a href="#0"><i class="arrow_back"></i> <span>Reply</span></a></li>
					                    </ul>
					                </div>
					            </div>
					            <!-- /row -->
					            <div class="row reply">
					                <div class="col-md-2 user_info">
					                    <figure><img src="img/avatar.jpg" alt=""></figure>
					                </div>
					                <div class="col-md-10">
					                    <div class="review_content">
					                        <strong>Reply from Chews Bite</strong>
					                        <em>Published 3 minutes ago</em>
					                        <p><br>Hi Marika,<br><br>Thank you for your review!<br><br>Thanks</p>
					                    </div>
					                </div>
					            </div>
					            <!-- /reply -->
					        </div>
					        <!-- /review_card -->
					    </div>
					    <!-- /reviews -->
					    <div class="text-end"><a href="leave-review.html" class="btn_1 gradient">Leave a Review</a></div>
					</section>
					<!-- /section -->
				</div>
			</div>
		</div>
		<!-- /container -->

	</main>
	<!-- /main -->

	<footer>
		<div class="wave footer"></div>
		<div class="container margin_60_40 fix_mobile">

			<div class="row">
				<div class="col-lg-3 col-md-6">
					<h3 data-bs-target="#collapse_1">Quick Links</h3>
					<div class="collapse dont-collapse-sm links" id="collapse_1">
						<ul>
							<li><a href="about.html">About us</a></li>
							<li><a href="submit-restaurant.html">Add your restaurant</a></li>
							<li><a href="help.html">Help</a></li>
							<li><a href="register.html">My account</a></li>
							<li><a href="blog.html">Blog</a></li>
							<li><a href="contacts.html">Contacts</a></li>
						</ul>
					</div>
				</div>
						<div class="follow_us">
							<h5>Follow Us</h5>
							<ul>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/twitter_icon.svg" alt="" class="lazy"></a></li>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/facebook_icon.svg" alt="" class="lazy"></a></li>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/instagram_icon.svg" alt="" class="lazy"></a></li>
								<li><a href="#0"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==" data-src="img/youtube_icon.svg" alt="" class="lazy"></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- /row-->
				<div class="col-lg-6">
					<ul class="additional_links">
						<li><a href="#0">Terms and conditions</a></li>
						<li><a href="#0">Privacy</a></li>
						<li><span>© Chews Bite</span></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<!--/footer-->

	<div id="toTop" class="detail_page"></div><!-- Back to top button -->

	
<!-- Sign In Modal -->
<div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
    <div class="modal_header">
        <h3>Sign In</h3>
    </div>
    <form>
        <div class="sign-in-wrapper">
            <a href="#0" class="social_bt facebook">Login with Facebook</a>
            <a href="#0" class="social_bt google">Login with Google</a>
            <div class="divider"><span>Or</span></div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" class="form-control" name="email" id="email">
                <i class="icon_mail_alt"></i>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="password" id="password" value="">
                <i class="icon_lock_alt"></i>
            </div>
            <div class="clearfix add_bottom_15">
                <div class="checkboxes float-start">
                    <label class="container_check">Remember me
                        <input type="checkbox">
                        <span class="checkmark"></span>
                    </label>
                </div>
                <div class="float-end"><a id="forgot" href="javascript:void(0);">Forgot Password?</a></div>
            </div>
            <div class="text-center">
                <input type="submit" value="Log In" class="btn_1 full-width mb_5">
                Don’t have an account? <a href="register.html">Sign up</a>
            </div>
            <div id="forgot_pw">
                <div class="form-group">
                    <label>Please confirm login email below</label>
                    <input type="email" class="form-control" name="email_forgot" id="email_forgot">
                    <i class="icon_mail_alt"></i>
                </div>
                <p>You will receive an email containing a link allowing you to reset your password to a new preferred one.</p>
                <div class="text-center"><input type="submit" value="Reset Password" class="btn_1"></div>
            </div>
        </div>
    </form>
    <!--form -->
</div>
<!-- /Sign In Modal -->

<!-- Modal item order -->
<div id="modal-dialog" class="zoom-anim-dialog mfp-hide">
    <div class="small-dialog-header">
        <h3>Cheese Quesadilla</h3>
    </div>
    <div class="content">
        <h5>Quantity</h5>
        <div class="numbers-row">
            <input type="text" value="1" id="qty_1" class="qty2 form-control" name="quantity">
        </div>
        <h5>Size</h5>
        <ul class="clearfix">
            <li>
                <label class="container_radio">Medium<span>+ $3.30</span>
                    <input type="radio" value="option1" name="options_1">
                    <span class="checkmark"></span>
                </label>
            </li>
            <li>
                <label class="container_radio">Large<span>+ $5.30</span>
                    <input type="radio" value="option2" name="options_1">
                    <span class="checkmark"></span>
                </label>
            </li>
            <li>
                <label class="container_radio">Extra Large<span>+ $8.30</span>
                    <input type="radio" value="option3" name="options_1">
                    <span class="checkmark"></span>
                </label>
            </li>
        </ul>
        <h5>Extra Ingredients</h5>
        <ul class="clearfix">
            <li>
                <label class="container_check">Extra Tomato<span>+ $4.30</span>
                    <input type="checkbox">
                    <span class="checkmark"></span>
                </label>
            </li>
            <li>
                <label class="container_check">Extra Peppers<span>+ $2.50</span>
                    <input type="checkbox">
                    <span class="checkmark"></span>
                </label>
            </li>
            <li>
                <label class="container_check">Extra Ham<span>+ $4.30</span>
                    <input type="checkbox">
                    <span class="checkmark"></span>
                </label>
            </li>
        </ul>
    </div>
    <div class="footer">
        <div class="row small-gutters">
            <div class="col-md-4">
                <button type="reset" class="btn_1 outline full-width mb-mobile">Cancel</button>
            </div>
            <div class="col-md-8">
                <button type="reset" class="btn_1 full-width">Add to cart</button>
            </div>
        </div>
        <!-- /Row -->
    </div>
    </div>



    <!-- /Modal item order -->
	
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/common_func.js"></script>
    <script src="assets/validate.js"></script>

    <!-- SPECIFIC SCRIPTS -->
    <script src="js/sticky_sidebar.min.js"></script>
    <script src="js/sticky-kit.min.js"></script>
    <script src="js/specific_detail.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
		document.getElementById('order_now').addEventListener('click', function () {
			var calhiddenValue = document.getElementById('calhidden').value;
			///window.location.href="http://studentnstp.orgfree.com/res/order.php?order="+calhiddenValue;

			var dataToSend = {
				key1: calhiddenValue
			};

			var xhr = new XMLHttpRequest();
			xhr.open("POST", "updatecal.php", true);
			xhr.setRequestHeader("Content-Type", "application/json");
			xhr.onreadystatechange = function () {
				if (xhr.readyState === 4 && xhr.status === 200) {
					console.log('Success:', xhr.responseText);
					// Handle successful response here
				} else if (xhr.readyState === 4) {
					console.error('Error:', xhr.status);
					// Handle error here
				}
			};
			xhr.send(JSON.stringify(dataToSend));



			///window.location.assign(window.location.protocol    +"order.php?order="+calhiddenValue)
                });
        // Initialize cart from localStorage
        var cart = JSON.parse(localStorage.getItem('cart')) || [];

        // Function to update the cart total, calories, and display cart items
        function updateCart() {
            var cartItemsContainer = document.getElementById('cart-items');
            var cartTotalCaloriesContainer = document.getElementById('cart-total-calories');
            var cartTotalContainer = document.getElementById('cart-total');

            // Clear existing cart items
            cartItemsContainer.innerHTML = '';

            // Get the state of the switch
            var showCalories = document.getElementById('toggleSwitch').checked;

            // Display cart items and calculate total calories (conditionally)
            var totalCalories = 0;
            cart.forEach(function (item) {
                var li = document.createElement('li');
                li.innerHTML = item.name + `<span>PHP${item.price.toFixed(2)}</span>`;

                // Add calories to the total (conditionally)
                if (showCalories) {
                    li.innerHTML += ``;
                    totalCalories += item.calories;
                }

                // Create a remove button with a trash can icon
                var removeButton = document.createElement('button');
                removeButton.className = 'remove-from-cart-btn';
                removeButton.innerHTML = '-';
                removeButton.dataset.productId = item.productId; // Assuming there's a unique identifier for each product

                // Add click event listener to remove the item when the button is clicked
                removeButton.addEventListener('click', function () {
                    // Find the index of the item in the cart
                    var index = cart.findIndex(function (cartItem) {
                        return cartItem.productId === item.productId;
                    });

                    // Remove the item from the cart
                    if (index !== -1) {
                        cart.splice(index, 1);
                    }

                    // Update the cart total, calories, and display cart items
                    updateCart();
                });

                li.appendChild(removeButton);
                cartItemsContainer.appendChild(li);
            });

            // Display total calories (conditionally)
            if (showCalories) {
                cartTotalCaloriesContainer.textContent = `${totalCalories}`;
            } else {
                cartTotalCaloriesContainer.textContent = ''; // Clear the total calories
            }

            // Display total price
            var totalPrice = cart.reduce(function (acc, item) {
                return acc + item.price;
            }, 0);
            cartTotalContainer.textContent = `PHP${totalPrice.toFixed(2)}`;

            // Save the updated cart to localStorage
            localStorage.setItem('cart', JSON.stringify(cart));
			document.getElementById('calhidden').value=totalCalories;

            // Check if total calories exceed 1600 and display alert
            if (showCalories && totalCalories > <?php echo $_SESSION['cal']; ?>) {
                alert('Unhealthy: Your Total Food calories exceed <?php echo $_SESSION['cal']; ?>cal');
				return false;
            }


			



        }

        // Add click event listener to the toggle switch
        var toggleSwitch = document.getElementById('toggleSwitch');
        if (toggleSwitch) {
            toggleSwitch.addEventListener('change', function () {
                // Update the cart display when the switch state changes
                updateCart();
            });
        }

        // Add click event listener to all 'Add to Cart' buttons
        var addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
        addToCartButtons.forEach(function (button) {
            button.addEventListener('click', function (event) {
                // Get the item details from the data attributes
                var item = {
                    name: button.parentElement.dataset.name,
                    price: parseFloat(button.parentElement.dataset.price),
                    calories: parseInt(button.parentElement.dataset.calories),
                    productId: button.parentElement.dataset.productId // Assuming there's a unique identifier for each product
                };

                // Add the item to the cart
                cart.push(item);

                // Update the cart total, calories, and display cart items
                updateCart();
            });
        });

        // Logout button event listener
        var logoutButton = document.getElementById('logout-btn');
        if (logoutButton) {
            logoutButton.addEventListener('click', function () {
                // Clear the cart items on logout
                cart = [];

                // Update the cart display
                updateCart();
            });
        }

        // Initial update to display any existing cart items
        updateCart();
    });
</script>




</body>
</html>