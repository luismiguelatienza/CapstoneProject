<?php

session_start();

require_once 'Config/Functions.php';
$Fun_call = new Functions();

if (isset($_SESSION['user_name']) && isset($_SESSION['user_uni_no'])) {
    header('Location:index.php');
}

$u_error = $p_error = $error_msg = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {

    $username = $Fun_call->validate($_POST['username']);
    $password = $Fun_call->validate($_POST['password']);

    $save_cookie = (isset($_POST['savepass'])) ? ($Fun_call->validate($_POST['savepass'])) : '';

    if ((!preg_match('/^[ ]*$/', $username)) && (!preg_match('/^[ ]*$/', $password))) {

        $verify_fields['u_name'] = $username;
        $verify_fields['u_pass'] = $password;
        $verify_user = $Fun_call->user_verify("user", $verify_fields);

        if ($verify_user) {

            $fetch_user_info = $Fun_call->select_assoc('user', $verify_fields);

            if (!empty(trim($save_cookie))) {

                setcookie('username', $username, time() + (365 * 24 * 60), "/");
                setcookie('userpass', $password, time() + (365 * 24 * 60), "/");

            }

            $_SESSION['user_name'] = $fetch_user_info['u_name'];
            $_SESSION['user_uni_no'] = $fetch_user_info['u_uni_no'];
            $_SESSION['bmi'] = $fetch_user_info['bmi'];
            $_SESSION['cal'] = $fetch_user_info['cal'];
            $_SESSION['order_date'] = $fetch_user_info['order_date'];
            $_SESSION['u_id'] = $fetch_user_info['u_id'];
            $_SESSION['is_order'] = false;
            $_SESSION['orders'] = $fetch_user_info['orders'];


            header('Location:index.php');

        } else {
            $error_msg = "Username and Password are Invalid";
        }

    } else {

        if (preg_match('/^[ ]*$/', $username)) {
            $u_error = "Please Enter Username";
        }
        if (preg_match('/^[ ]*$/', $password)) {
            $p_error = "Please Enter Password";
        }

    }
} else {
    $error_msg = "Invalid Request Not Allowed";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Chews Bite - Quality delivery or takeaway food">
    <meta name="author" content="Ansonika">
    <title>Chews Bite - Quality delivery or takeaway food</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="https://cdn-icons-png.flaticon.com/512/7217/7217494.png" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

    <!-- GOOGLE WEB FONT -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- SPECIFIC CSS -->
    <link href="css/order-sign_up.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">
    
</head>

<body id="register_bg">
	
	<div id="register">
		<aside>
        <span style="font-weight: 800;font-size: 32px;"><span style="color:#E38C3F">Chews</span> Bite</span>
			<div class="access_social">
					<!-- <a href="#0" class="social_bt facebook">Login with Facebook</a>
					<a href="#0" class="social_bt google">Login with Google</a> -->
				</div>
            <!-- <div class="divider"><span>Or</span></div> -->
        <form class="login-box" method="post" id="form">
				<div class="form-group">
                    <input type="text" id="username" name="username" class="form-control mb-2" placeholder="Username" value="<?php echo @$_COOKIE['username']; ?>" autofocus>
                    <i class="icon_mail_alt"></i>
                    <span class="error-msg"><?php echo @$u_error; ?></span>
				</div>
				<div class="form-group">
                    <input type="password" id="password" name="password" class="form-control mb-2" placeholder="Password" value="<?php echo @$_COOKIE['userpass']; ?>">
                    <i class="icon_lock_alt"></i>
                    <span class="error-msg"><?php echo @$p_error; ?></span>
				</div>
				<div class="clearfix add_bottom_15">
					<div class="checkboxes float-start">
						<!-- <label class="container_check">Remember me
                            <input type="checkbox" class="custom-control-input" id="savepass" name="savepass" value="savepass">
						  <span class="checkmark"></span>
						</label> -->
					</div>
					<div class="float-end"></div>
				</div>
                <span class="error-msg"><?php echo @$error_msg; ?></span>
                                <input class="btn_1 gradient full-widthn" name="submit" value="submit" type="submit">
				<div class="text-center mt-2"><small>Don't have an acccount? <strong><a href="register.php">Sign Up</a></strong></small></div>
			</form>
			<div class="copy">© 2020 ChewsBite</div>
		</aside>
	</div>

</body>
</html>
